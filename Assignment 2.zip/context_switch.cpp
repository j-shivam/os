#include <bits/stdc++.h>
#include <sys/time.h>
#include <sched.h>
#include <unistd.h>
#include <sys/wait.h>
using namespace std;

int main()
{   
    struct timeval start[2],end[2];
    
    float time_taken1;
    float time_taken2;
    float total_time_taken;
    float average_time;
    
    int process1[2];
    int process2[2];    
    
    char *proc1_msg = "Hi!";
    char *proc2_msg = "Hi!";
    char rec_proc1[3];
    char rec_proc2[3];
        
    if(pipe(process1) == -1)
    {
        perror("Pipe 1");
        exit(EXIT_FAILURE);
    }

    if(pipe(process2) == -1)
    {
        perror("Pipe 2");
        exit(EXIT_FAILURE);
    }

    
    pid_t pid;
    pid = fork();

    cpu_set_t set_cpu;
    CPU_ZERO(&set_cpu);
    CPU_SET(0,&set_cpu);
    sched_setaffinity(0, sizeof(cpu_set_t), &set_cpu);

    if(pid == -1) 
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    else if(pid == 0)
    {
        cout<<"Child Process Ran"<<endl;

        gettimeofday(&start[1],NULL);

        for(int i=0;i<50;i++)
        {
            write(process1[1],proc2_msg,3);
            wait(NULL);
            read(process2[0],rec_proc1,3);
        }

        gettimeofday(&end[1],NULL);

        time_taken2=(end[1].tv_usec-start[1].tv_usec);

        if(time_taken1 != 0)
        {
            total_time_taken = time_taken1 + time_taken2;
            average_time = total_time_taken/100;
            cout<<"Average context switching time is "<<average_time<<" microseconds"<<endl;

            time_taken1 = 0;
        }
    }

    else
    {
        cout<<"Parent Process Ran"<<endl;

        gettimeofday(&start[0],NULL);

        for(int i=0;i<50;i++)
        {
            read(process1[0],rec_proc2,3);
            write(process2[1],proc1_msg,3);
        }

        gettimeofday(&end[0],NULL);

        time_taken1=(end[0].tv_usec-start[0].tv_usec);

        if(time_taken2 != 0)
        {
            total_time_taken = time_taken1 + time_taken2;
            average_time = total_time_taken/100;
            cout<<"Average context switching time is "<<average_time<<" microseconds"<<endl;

            time_taken2 == 0;
        }
    }
    
    return 0;
}
