#include<bits/stdc++.h>
using namespace std;

int find_func(vector<int> v1, int temp)
{
    for(int i=0; i<v1.size(); i++)
    {
        if(v1[i]==temp)
            return i;
        
        if(v1[i]==-1)
            return -1;
    }

    return -1;
}

int main()
{
    int n, N;
    
    FILE *fp;
    fp = freopen("input.dat", "r", stdin);

    cin>>N;

    vector<int> v(N);

    for(int i=0; i<N; i++)
    {
        int temp;
        cin>>temp;

        if(temp == -1)
            break;
        
        v[i] = temp;
    }

    cin>>n;
    cin>>n;
    vector<int> v1(n);

    for(int i=0; i<n; i++)
    {
        v1[i] = -1;
    }

    for(int i=0; i<v.size(); i++)
    {
        int check = find_func(v1, v[i]);
        
        if(check!=-1)
        {
            cout<<"Page "<<v[i]<<" found"<<endl;
            int k=check;
            while(k<v.size()-1 && v1[k+1]!=-1)
            {
                swap(v1[check], v1[check+1]);
                k++;
            }
        }
            
        
        else
        {
            if(v1[v1.size()-1]==-1)
            {
                cout<<"Page "<<v[i]<<" not found but nothing will be replaced"<<endl;
                for(int j=0; j<v1.size(); j++)
                {
                    if(v1[j] == -1)
                    {
                        v1[j] = v[i];
                        break;
                    }
                }
            }

            else
            {
                cout<<"Page "<<v[i]<<" not found.....Page "<<v1[0]<<" will be replaced"<<endl;
                v1.erase(v1.begin());
                v1[v1.size()-1] = v[i];
            }
        }
    }
}