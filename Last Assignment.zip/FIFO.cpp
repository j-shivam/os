#include<bits/stdc++.h>
using namespace std;

int find_func(vector<int> v1, int temp)
{
    for(int i=0; i<v1.size(); i++)
    {
        if(v1[i]==temp)
            return 1;
        
        if(v1[i]==-1)
            return -1;
    }

    return -1;
}

int main()
{
    int n, N;
    
    FILE *fp;
    fp = freopen("input.dat", "r", stdin);

    cin>>N;
    cout<<N<<endl;
    vector<int> v(N, 0);

    for(int i=0; i<N; i++)
    {
        int temp;
        cin>>temp;
        cout<<temp<<" ";

        if(temp == -1)
            break;
        
        v[i] = temp;
    }
    cout<<endl;

    cin>>n;
    cin>>n;
    cout<<n<<endl;
    vector<int> v1(n, -1);

    

    for(int i=0; i<v.size(); i++)
    {
        if(find_func(v1, v[i])==1)
            cout<<"Page "<<v[i]<<" found"<<endl;
        
        else
        {
            if(v1[v1.size()-1]==-1)
            {
                cout<<"Page "<<v[i]<<" not found but nothing will be replaced"<<endl;
                for(int j=0; j<v1.size(); j++)
                {
                    if(v1[j] == -1)
                    {
                        v1[j] = v[i];
                        break;
                    }
                }
            }

            else
            {
                cout<<"Page "<<v[i]<<" not found.....Page "<<v1[0]<<" will be replaced"<<endl;
                v1.erase(v1.begin());
                v1[v1.size()-1] = v[i];
            }
        }
    }
}