#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/wait.h>

#define n 3
#define	NTURN 50

#define TRUE 1
#define FALSE 0

int choosing[n];
int tickets[n];

int max_elmt = 0;

pthread_t	t[n];

int maxx(int arr[])
{
    int max = arr[0];
    for(int i = 0; i<n; i++)
    {
        if(arr[i]>max)
            max_elmt = arr[i];
    }
    return max_elmt;
}

void	*thread(void *args) 
{
    int x = *(int *) args;

    for(int i=0; i<n; i++)
    {
        tickets[i] = 0;
    }

    for(int j=0; j<NTURN; j++)
    {
        choosing[x] = TRUE;
        tickets[x] = maxx(tickets) + 1;
        choosing[x] = FALSE;

        for(int i=0; i<n; i++)
        {
            if(i == x)
            {
                continue;
            }

            while(choosing[x] != FALSE) ;

            while(tickets[i] != 0 && tickets[i] < tickets[x]) ;

            if(tickets[i] == tickets[x] && i < x) 
            {
                while(tickets[i] != 0);
            }
        }

        printf("%d using resource...\n", x);
        tickets[x] = 0;
    }
}

void	main(void) {
	for(int i=0; i<n; i++)
        if( pthread_create(&t[i], NULL, thread, &i) != 0) {
            printf("Thread two not created. Quitting.\n");
            exit(0);
        }

    for(int i=0; i<n; i++)
        if(pthread_join(t[i], NULL) != 0) {
            //perror("Thread 1 (exit) ");
            exit(0);
        }
	
	return;
}
