#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<semaphore.h>

#define N 5

pthread_t phils[N];
sem_t forks[N], fmutex;
int state[N];

// States:
//     -1 --> Thinking
//      0 --> Eating
//      1 --> Hungry

int right(int p)
{
    return (p+1)%N;
}

int left(int p)
{
    return (p+4)%N;
}

void check(int phil) 
{ 
    if (state[phil] == 1 && state[left(phil)] != 0 && state[right(phil)] != 0)
    { 
        state[phil] = 0; 

        float temp = (rand()%7)/5;
  
        sleep(temp);
  
        printf("Philosopher %d takes fork %d and %d and eating...\n", phil + 1, phil + 1, left(phil) + 1); 
  
        sem_post(&forks[phil]); 
    } 
} 

void take_fork(int phil) 
{ 
  
    sem_wait(&fmutex); 
  
    state[phil] = 1; 
  
    printf("Philosopher %d is Hungry\n", phil + 1); 
  
    check(phil); 
  
    sem_post(&fmutex); 
  
    sem_wait(&forks[phil]);

    sleep((float)((rand()%7)/5));
} 

void put_fork(int phil) 
{ 
  
    sem_wait(&fmutex); 
  
    state[phil] = -1;
  
    printf("Philosopher %d putting fork %d and %d down and starting thinking\n", phil + 1, phil + 1, left(phil) + 1);
    
    check(left(phil));

    check(right(phil));
    
  
    sem_post(&fmutex);
} 

void *dine(void *args)
{
    int *p;
    p = (int *) args;

    while(1)
    {
        sleep((float)((rand()%7)/5));

        take_fork(*p);

        sleep((float)((rand()%7)/5));

        put_fork(*p);
    }
}

int main(int argc, char *argv[])
{
    sem_init(&fmutex, 0, 1);

    int *arr;
    arr = (int *)malloc(N * sizeof(int));

    for(int i=0; i<N; i++)
    {
        sem_init(&forks[i], 0, 0);
        arr[i] = i;
    }

    for(int i=0; i<N; i++)
    {
        pthread_create(&phils[i], NULL, dine, &arr[i]);

        printf("Philosopher %d is thinking\n", i + 1);
    }

    for(int i=0; i<N; i++)
    {
        pthread_join(phils[i], NULL);
    }
}