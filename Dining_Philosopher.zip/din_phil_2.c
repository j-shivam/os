#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<semaphore.h>

#define N 5

pthread_t  phils[N];
sem_t forks[N];

int left(int p)
{
    return p;
}

int right(int p)
{
    if(p==0)
        return (p+4)%5;

    return (p-1)%5;
}

void *dine(void *args)
{
    int p = *(int *) args;
    float temp;

    if(left(p) < right(p))
    {
        sem_wait(&forks[left(p)]);
        sem_wait(&forks[right(p)]);

        temp = (rand()%7)/10;
        sleep(temp);
        printf("%d is eating...\n", p+1);
        
        sem_post(&forks[right(p)]);
        sem_post(&forks[left(p)]);
    }

    else
    {
        sem_wait(&forks[right(p)]);
        sem_wait(&forks[left(p)]);
        
        temp = (rand()%7)/10;
        sleep(temp);
        printf("%d is eating...\n", p+1);
        
        sem_post(&forks[left(p)]);
        sem_post(&forks[right(p)]);
    }
}

int main(int argc, char *argv[])
{
    int *arr;
    arr = (int *)malloc(N * sizeof(int));

    for(int i=0; i<N; i++)
    {
        sem_init(&forks[i],0,1);
        arr[i] = i;
    }
    
    for(int i=0; i<N; i++)
    {
        pthread_create(&phils[i], NULL, dine, &arr[i]);
    }

    for(int i=0; i<N; i++)
    {
        pthread_join(phils[i], NULL);
    }
}