#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
#include<sys/wait.h>

int N = 5;

int read_count = 0, write_count = 0, num_readr, num_writr;
sem_t lock, qlock, rmutex, wmutex, readTry;

int *rdrs_waiting, *wrtrs_waiting;

#include "readers_pref.h"
#include "writers_pref.h"
#include "no_pref.h"

int main(int argc, char *argv[])
{
    int select;
    select = atoi(argv[1]);
    num_readr = atoi(argv[2]);
    num_writr = atoi(argv[3]);

    rdrs_waiting = (int *) malloc(num_readr * sizeof(int));
    wrtrs_waiting = (int *) malloc(num_writr * sizeof(int));    
    
    for(int i=0; i<num_readr; i++)
    {
        rdrs_waiting[i] = 0;
    }

    for(int i=0; i<num_writr; i++)
    {
        wrtrs_waiting[i] = 0;
    }

    if(select == 1)
        readers_pref();

    else if(select == 2)
        writers_pref(num_readr, num_writr);

    else if(select == 3)
        no_pref(num_readr, num_writr);
}