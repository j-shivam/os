// #include<stdio.h>
// #include<stdlib.h>
// #include<pthread.h>
// #include<semaphore.h>
// #include<unistd.h>
// #include<sys/wait.h>

// int read_count = 0;
// sem_t lock, qlock, rmutex;

void *wrtr3(void *args)
{
    float time;
    int p = *(int*)args;

    for(int i=0; i<N; i++)
    {
        wrtrs_waiting[p] = 1;

        sem_wait(&qlock);
        sem_wait(&lock);

        wrtrs_waiting[p] = 0;
        
        sem_post(&qlock);
        
        time = (rand()%7)/10;
        sleep(time);
        printf("Writer %d writing...\n", p);

        printf("Writers Waiting : ");
        for(int j=0; j<num_writr; j++)
        {
            if(wrtrs_waiting[j] == 1)
                printf("%d ", j);
        }

        printf("    Readers Waiting : ");
        for(int j=0; j<num_readr; j++)
        {
            if(rdrs_waiting[j] == 1)
                printf("%d ", j);
        }

        printf("\n\n");
        
        sem_post(&lock);
    }
}

void *rdr3(void *args)
{
    float time;
    int p = *(int*)args - 1;

    for(int i=0; i<N; i++)
    {
        rdrs_waiting[p] = 1;

        sem_wait(&qlock);
        sem_wait(&rmutex);

        rdrs_waiting[p] = 0;
        
        if(read_count==0)
        {
            rdrs_waiting[p] = 1;
            sem_wait(&lock);
            rdrs_waiting[p] = 0;
        }
        
        read_count++;
        
        sem_post(&qlock);
        sem_post(&rmutex);
        
        time = (rand()%7)/10;
        sleep(time);

        printf("Reader %d reading...\n", p);

        printf("Writers Waiting : ");
        for(int j=0; j<num_writr; j++)
        {
            if(wrtrs_waiting[j] == 1)
                printf("%d ", j);
        }

        printf("    Readers Waiting : ");
        for(int j=0; j<num_readr; j++)
        {
            if(rdrs_waiting[j] == 1)
                printf("%d ", j);
        }

        printf("\n\n");
        
        rdrs_waiting[p] = 1;
        sem_wait(&rmutex);
        rdrs_waiting[p] = 0;
        
        read_count--;
        if(read_count==0)
        {
            sem_post(&lock);
        }
        
        sem_post(&rmutex);
    }
}

void no_pref(int num_readr, int num_writr)
{
    // int num_writr, num_readr;
    // num_writr = atoi(argv[1]);
    // num_readr = atoi(argv[2]);

    pthread_t rdrs[num_readr];
    pthread_t wrtrs[num_writr];

    sem_init(&lock, 0, 1);
    sem_init(&qlock, 0, 1);
    sem_init(&rmutex, 0, 1);

    int i=0, j=0;

    printf("No Preference ----------------------\n\n");

    while(i<num_readr && j<num_writr)
    {   
        pthread_create(&rdrs[i], NULL, rdr1, &i);
        pthread_create(&wrtrs[j], NULL, wrtr1, &j);

        i++;
        j++;
    }

    while(i<num_readr)
    {
        pthread_create(&rdrs[i], NULL, rdr1, &i);
        i++;
    }

    while(j<num_writr)
    {
        pthread_create(&wrtrs[i], NULL, rdr1, &j);
        j++;
    }

    for(int i=0; i<num_readr; i++)
    {
        pthread_join(rdrs[i], NULL);
    }

    for(int i=0; i<num_writr; i++)
    {
        pthread_join(wrtrs[i], NULL);
    }
}