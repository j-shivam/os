// Please check this code for errors.
// I don't know why it isn't giving correct output.

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
#include<sys/wait.h>

int buffer[10];
int value = 0;
pthread_t prdcr, cnsmr1, cnsmr2;
sem_t mutex, empty, full, cons;

void *producer(void *args)
{
    while(1)
    {
        int count;
        sem_getvalue(&full, &count);

        sem_wait(&empty);    
        sem_wait(&mutex);

        sleep((rand()%7)/10);
        printf("Producer is producing...");

        sem_post(&mutex);
        sem_post(&full);

        printf(" %d\n", count);
    }
}

void *consumer1(void *args)
{
    while(1)
    {
        int count;
        sem_getvalue(&full, &count);
        sem_wait(&cons);
        sem_wait(&full);
        sem_wait(&mutex);
        
        sleep((rand()%7)/10);
        printf("Consumer1 is consuming...");

        sem_post(&mutex);
        sem_post(&empty);
        sem_post(&cons);
        printf(" %d\n", count);
    }
}

void *consumer2(void *args)
{
    while(1)
    {
        int temp;
        sem_getvalue(&full, &temp);

        if(temp >=2 )
        {
            int count;
            sem_getvalue(&full, &count);

            sem_wait(&cons);
            sem_wait(&full);
            sem_wait(&full);
            sem_wait(&mutex);

            sleep((rand()%7)/10);
            printf("Consumer2 is consuming...");

            
            sem_post(&mutex);
            sem_post(&empty);
            sem_post(&empty);
            sem_post(&cons);
            
            printf(" %d\n", count);
        }
    }
}

int main()
{
    sem_init(&mutex, 0, 1);
    sem_init(&cons, 0, 1);
    sem_init(&full, 0, 0);
    sem_init(&empty, 0, 10);

    pthread_create(&prdcr, NULL, producer, NULL);
    pthread_create(&cnsmr1, NULL, consumer1, NULL);
    pthread_create(&cnsmr2, NULL, consumer2, NULL);
    pthread_join(prdcr, NULL);
    pthread_join(cnsmr1, NULL);
    pthread_join(cnsmr2, NULL);
}
