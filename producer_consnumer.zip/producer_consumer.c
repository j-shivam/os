#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
#include<sys/wait.h>

int buffer = 0;
int max = 10;
pthread_t prdcr, cnsmr1, cnsmr2;
sem_t pmutex, cmutex;

void *producer(void *args)
{
    while(1)
    {
        sleep((rand()%7)/5);

        sem_wait(&pmutex);

        if(buffer == max)
        {
            sem_post(&pmutex);
            sleep((rand()%7)/5);
            continue;
        }
        
        buffer++;

        printf("Producer is producing... %d\n", buffer);

        sem_post(&pmutex);
    }
}

void *consumer1(void *args)
{
    while(1)
    {
        sleep((rand()%7)/5);

        sem_wait(&cmutex);
        sem_wait(&pmutex);

        if(buffer == 0)
        {
            sem_post(&pmutex);
            while(buffer == 0) ;
            sem_wait(&pmutex);
        }
        
        buffer--;
        printf("Consumer1 is consuming... %d\n", buffer);

        sem_post(&pmutex);
        sem_post(&cmutex);        
    }
}

void *consumer2(void *args)
{
    while(1)
    {
        sleep((rand()%7)/5);
        
        sem_wait(&cmutex);
        sem_wait(&pmutex);

        if(buffer < 2)
        {
            sem_post(&pmutex);
            while(buffer < 2) ;
            sem_wait(&pmutex);
        }
        
        buffer--;
        buffer--;

        printf("Consumer2 is consuming... %d\n", buffer);

        sem_post(&pmutex);
        sem_post(&cmutex);        
    }
}

int main()
{
    sem_init(&pmutex, 0, 1);
    sem_init(&cmutex, 0, 1);

    pthread_create(&prdcr, NULL, producer, NULL);
    pthread_create(&cnsmr1, NULL, consumer1, NULL);
    pthread_create(&cnsmr2, NULL, consumer2, NULL);
    pthread_join(prdcr, NULL);
    pthread_join(cnsmr1, NULL);
    pthread_join(cnsmr2, NULL);
}
