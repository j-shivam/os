#include<bits/stdc++.h>
using namespace std;

struct Process
{
    int pid;
    int arr_time;
    int cpu_time;
    int prty;
};

bool compare(Process A, Process B)
{
    if(A.arr_time == B.arr_time)
    {
        return (A.prty < B.prty);
    }

    return (A.arr_time < B.arr_time);
}

bool arrange(Process A, Process B)
{
    return (A.prty < B.prty);
}

int main()
{
    fstream file;
    string str = "", s = "" ;
    int count = 0, num_process;
    vector<int> arr_time,cpu_time,prty_time;
    int arr,cpu,prty,id;

    file.open("input.txt");

    int counter = 0;

    file>>s;
    stringstream geek(s);
    geek>>num_process;   

    int quantum=0;

    vector<Process> processes;

    while (!file.eof())
    {
        count++;
        getline(file,str);

        if(str[0] == -1)
        {
            break;
        }
        
        if(count>1)
        {
            stringstream geek(str);
            geek>>id>>arr>>cpu>>prty;
            
            processes.push_back({id, arr, cpu, prty});
        }

        if(count>1+num_process)
        {
            stringstream geek(str);
            geek>>quantum;
        }
    }

    vector<Process> temp;
    int i = 0;
    int j=1;
    vector<Process> order;
    sort(processes.begin(), processes.end(), compare);

    int timer = processes[i].cpu_time;

    order.push_back(processes[0]);

    i++;

    int k=0;

    while(j<num_process || !temp.empty())
    {
        for(j; j<num_process; j++)
        {
            if(processes[j].arr_time <= timer)
            {
                temp.push_back(processes[j]);
            }

            else
            {
                break;
            }
            

        }

        sort(temp.begin(), temp.end(), arrange);

        timer = timer + temp[0].cpu_time;

        

        order.push_back(temp[0]);

        temp.erase(temp.begin());
    }

    for(int k=0; k<order.size(); k++)
    {
        cout<<order[k].pid<<" ";
    }

    cout<<endl<<endl;

    float turn_around = 0, response_time = 0;

    for(int i=0; i<num_process; i++)
    {
        int j = i, temp = 0;
        while (j>=0)
        {
            temp = temp + order[j].cpu_time;
            j--;
        }

        turn_around = temp + turn_around - order[j].arr_time;

        j=i, temp = 0;

        while (j--)
        {
            temp = temp + processes[j].cpu_time;
        }

        response_time = response_time + temp - order[j].arr_time;
    }

    turn_around = turn_around/num_process;
    response_time = response_time/num_process;
    float wait_time = response_time;

    if(response_time<0)
        response_time = 0;

    cout<<"Turn Around Time : "<<turn_around<<endl;
    cout<<"Response Time : "<<response_time<<endl;
    cout<<"Wait Time : "<<wait_time<<endl;
}