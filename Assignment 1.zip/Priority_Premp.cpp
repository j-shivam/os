#include<bits/stdc++.h>
using namespace std;

struct Process
{
    int pid;
    int arr_time;
    int cpu_time;
    int prty;
};

bool compare(Process A, Process B)
{
    if(A.arr_time == B.arr_time)
    {
        return (A.prty < B.prty);
    }

    return (A.arr_time < B.arr_time);
}

bool arrange(Process A, Process B)
{
    return (A.prty < B.prty);
}

int main()
{
    fstream file;
    string str = "", s = "" ;
    int count = 0, num_process;
    vector<int> arr_time,cpu_time,prty_time;
    int arr,cpu,prty,id;

    file.open("input.txt");

    int counter = 0;

    file>>s;
    stringstream geek(s);
    geek>>num_process;   

    int quantum=0;

    vector<Process> processes;

    while (!file.eof())
    {
        count++;
        getline(file,str);

        if(str[0] == -1)
        {
            break;
        }
        
        if(count>1)
        {
            stringstream geek(str);
            geek>>id>>arr>>cpu>>prty;
            
            processes.push_back({id, arr, cpu, prty});
        }

        if(count>1+num_process)
        {
            stringstream geek(str);
            geek>>quantum;
        }
    }

    vector<Process> temp;
    int i = 0;
    int j=0;
    vector<Process> order;
    sort(processes.begin(), processes.end(), compare);

    int timer = 0;

    processes[i].cpu_time = processes[i].cpu_time - timer;

    order.push_back(processes[0]);

    i++;

    int start[num_process], end[num_process];

    for(int i=0; i<num_process; i++)
    {
        start[i] = -1;
    }

    while(j<num_process || !temp.empty())
    {
        for(j; j<num_process; j++)
        {
            if(processes[j].arr_time <= timer)
            {
                temp.push_back(processes[j]);
            }

            else
            {
                break;
            }
            
        }

        sort(temp.begin(), temp.end(), arrange);

        if(start[temp[0].pid-1]==-1)
        {
            start[temp[0].pid-1]=timer;
        }

        timer += 1;
        
        temp[0].cpu_time--;
        
        if(temp[0].cpu_time==0)
        {
            end[temp[0].pid - 1] = timer;
            temp.erase(temp.begin());
        }
    }

    float turn_around = 0, wait_time = 0, resp_time = 0;
    int tat[num_process], wt[num_process], res[num_process];

    for(int i=0; i<order.size(); i++)
    {
        res[i] = start[i] - processes[i].arr_time;
        tat[i] = end[i] - processes[i].arr_time;
        wt[i] = tat[i] - processes[i].cpu_time; 

        turn_around += tat[i];
        wait_time += wt[i];
        resp_time += res[i];
    }

    turn_around = turn_around/num_process;
    wait_time = wait_time/num_process;
    resp_time = resp_time/num_process;

    cout<<"Turn Around Time : "<<turn_around<<endl;
    cout<<"Wait Time : "<<wait_time<<endl;
    cout<<"Response Time : "<<resp_time<<endl;
}