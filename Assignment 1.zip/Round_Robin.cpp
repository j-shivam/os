#include<bits/stdc++.h>
using namespace std;

struct Process
{
    int pid;
    int arr_time;
    int cpu_time;
    int prty;
};

bool compare(Process A, Process B)
{
    if(A.arr_time == B.arr_time)
    {
        return (A.prty < B.prty);
    }

    return (A.arr_time < B.arr_time);
}

bool arrange(Process A, Process B)
{
    return (A.prty < B.prty);
}

int main()
{
    fstream file;
    string str = "", s = "" ;
    int count = 0, num_process;
    vector<int> arr_time,cpu_time,prty_time;
    int arr,cpu,prty,id;

    file.open("input.txt");

    int counter = 0;

    file>>s;
    stringstream geek(s);
    geek>>num_process;   

    int quantum=0;

    vector<Process> processes;

    while (!file.eof())
    {
        count++;
        getline(file,str);

        if(str[0] == -1)
        {
            break;
        }
        
        if(count>1)
        {
            stringstream geek(str);
            geek>>id>>arr>>cpu>>prty;
            
            processes.push_back({id, arr, cpu, prty});
        }

        if(count>1+num_process)
        {
            stringstream geek(str);
            geek>>quantum;
        }
    }

    sort(processes.begin(), processes.end(), compare);

    vector<Process> temp_proc;
    temp_proc.assign(processes.begin(), processes.end());

    int turn_around[num_process], response_time[num_process], wait_time[num_process], compl_time[num_process];

    int timer = 0;

    while (true)
    {
        int stop = 1;

        for(int i=0; i<num_process; i++)
        {
            if(temp_proc[i].arr_time <= timer)
            {
                if(temp_proc[i].arr_time <= quantum)
                {
                    if(temp_proc[i].cpu_time > 0)
                    {
                        stop = 0;

                        if(temp_proc[i].cpu_time > quantum)
                        {
                            timer = timer + quantum;
                            temp_proc[i].cpu_time -= quantum;
                            temp_proc[i].arr_time += quantum;
                        }

                        else
                        {
                            timer += temp_proc[i].cpu_time;
                            compl_time[i] = timer - processes[i].arr_time;
                            wait_time[i] = timer - processes[i].arr_time - processes[i].cpu_time;
                            temp_proc[i].cpu_time = 0;
                        }
                    }
                }

                else if (temp_proc[i].arr_time > quantum)
                {
                    for (int j = 0; j < num_process; j++)
                    {
                        if (temp_proc[j].arr_time < temp_proc[i].arr_time) 
                        { 
                            if (temp_proc[j].cpu_time > 0) 
                            { 
                                stop = 0; 
                                if (temp_proc[j].cpu_time > quantum) 
                                { 
                                    timer += quantum; 
                                    temp_proc[j].cpu_time -= quantum; 
                                    temp_proc[j].arr_time += quantum; 
                                } 
                                
                                else 
                                { 
                                    timer += temp_proc[j].cpu_time; 
                                    compl_time[j] = timer - processes[j].arr_time; 
                                    wait_time[j] = timer - processes[j].cpu_time - processes[j].arr_time; 
                                    temp_proc[j].cpu_time = 0;
                                } 
                            } 
                        } 
                    }

                    if(temp_proc[i].cpu_time > 0)
                    {
                        stop = 0;

                        if(temp_proc[i].cpu_time > quantum)
                        {
                            timer += quantum;
                            temp_proc[i].cpu_time -= quantum;
                            temp_proc[i].arr_time += quantum;
                        }

                        else
                        {
                            timer += temp_proc[i].cpu_time;
                            compl_time[i] = timer - processes[i].arr_time;
                            wait_time[i] = compl_time[i] - processes[i].cpu_time;
                            temp_proc[i].cpu_time = 0;
                        }
                    }
                }
            }

            else if(temp_proc[i].arr_time > timer)
            {
                timer++;
                i--;
            }
        }

        if(stop)
        {
            break;
        }
    }

    float tat=0,wt=0;

    for(int i=0; i<num_process; i++)
    {
        turn_around[i] = compl_time[i] - processes[i].arr_time;
        wait_time[i] = turn_around[i] - processes[i].cpu_time; 

        tat += turn_around[i];
        wt += wait_time[i];
    }

    tat = tat/num_process;
    wt = wt/num_process;


    cout<<"Turn Around Time : "<<tat<<endl;
    cout<<"Wait Time : "<<wt<<endl;
}