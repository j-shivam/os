#include<bits/stdc++.h>
using namespace std;

int main()
{
    fstream file;
    string str = "", s = "" ;
    int count = 0, num_process;
    vector<int> arr_time,cpu_time,prty_time;
    int arr,cpu,prty;

    file.open("input1.txt");

    file>>s;
    stringstream geek(s);
    geek>>num_process;  

    int quantum=0;  

    while (!file.eof())
    {
        count++;
        getline(file,str);

        if(str[0] == -1)
        {
            break;
        }
        
        if(count>1)
        {
            stringstream geek(str);
            geek>>arr>>cpu>>prty;
            
            arr_time.push_back(arr);
            cpu_time.push_back(cpu);
            prty_time.push_back(prty);
        }

        if(count>1+num_process)
        {
            stringstream geek(str);
            geek>>quantum;
        }
    }

    float turn_around = 0, response_time = 0;

    for(int i=0; i<num_process; i++)
    {
        int j = i, temp = 0;
        while (j>=0)
        {
            temp = temp + cpu_time[j];
            j--;
        }

        turn_around = temp + turn_around - arr_time[i];

        j=i, temp = 0;

        while (j--)
        {
            temp = temp + cpu_time[j];
        }

        response_time = response_time + temp - arr_time[i];
    }

    turn_around = turn_around/num_process;
    response_time = response_time/num_process;
    float wait_time = response_time;

    if(response_time<0)
        response_time = 0;

    cout<<"Turn Around Time : "<<turn_around<<endl;
    cout<<"Response Time : "<<response_time<<endl;
    cout<<"Wait Time : "<<wait_time<<endl;
}